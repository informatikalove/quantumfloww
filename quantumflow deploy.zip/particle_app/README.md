# 🌌 QuantumFlow

Simulasi fisika partikel interaktif — 3 mode: Gravitasi, Ledakan, Black Hole.

## Deploy ke Railway
1. Upload folder ini ke GitHub
2. Buka railway.app → New Project → Deploy from GitHub
3. Pilih repo ini → tunggu 2 menit → dapat link!

## Jalankan Lokal
```bash
pip install flask
python app.py
```
Buka: http://localhost:5001
